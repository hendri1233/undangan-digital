document.addEventListener("DOMContentLoaded", function() {
    console.log("Undangan siap!");
});
